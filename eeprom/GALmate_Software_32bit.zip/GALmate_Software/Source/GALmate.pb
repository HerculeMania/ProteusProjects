﻿#APP_NAME="GALmate"
#APP_VERSION="Version 1.1"
#APP_BY="by Yorck Thiele"
#APP_BUILT=#PB_Compiler_Date
#MAXFUSES=10000
#MAXFILESIZE=20000
#MAXCOMPORTS=32
#FUSE_ADRESS_DIGITS=5

#VREF=7.15
#GAIN=2.674
#VPP_READ=12
#VCC=5

#InBufSize=1000
#OutBufSize=1000
#PWR_ON_MSG="GALmate_V1.0"

;error level
#ERR_IEC=1
#ERR_ATMEGA=2
#ERR_CANCEL=4

;row types
Enumeration
  #FUSEMAP ;AND array
  #FUSE_OR ;OR array
  #UES     ; user electronic signature
  #PES     ;programmer electronic signature (ATF = text string, others = Vendor/Vpp/timing)
  #ACW     ; architecture control word
  #BULKERASE ;erase AND array, ACW & UES 
  #ERASEALL  ;erase PES also
  #SECURITY
  #ATMEL_PD_DIS ;disable ATMEL power-down feature; (JEDEC fuse: total_fuses+1; e.g. ATF22V10 #5892)
  #Font_0
  #Font_1
  #Font_2
  #Font_3
  #MSGINFO
  #MSGWARNING
  #MSGERROR
  #MENU_OPEN
  #MENU_SAVE
  #MENU_CLEARALL
  #MENU_SET_UES
  #MENU_COPY_PES
  #MENU_ATMEL_PD_DIS
  #MENU_SECURITY
  #MENU_ATMEL_CONDITIONING
  #MENU_SUPPLY_TEST
  #MENU_ABOUT
  #MENU_SUPPORTED_DEVICES
  #TBAR_OPEN
  #TBAR_SAVE
  #TBAR_COMPILE
  #TBAR_READ
  #TBAR_WRITE
  #TBAR_VERIFY
  #TBAR_ERASE
  #TBAR_INFO
  #TBAR_TEST
  #PIN_FUNC_INP
  #PIN_FUNC_GND
  #PIN_FUNC_VCC
  #PIN_FUNC_I_CLK
  #PIN_FUNC_I_CLK2
  #PIN_FUNC_I_O
  #PIN_FUNC_I_OE
  #PIN_FUNC_OE
  #PIN_FUNC_PL
  #PIN_FUNC_OCLK
  
EndEnumeration

;GAL IDs
;ATMEL ATF >= 0x80 dummy device code
#MAX_ACW_FUSES=256
#MAX_PINS=28
#GAL16V8=0
#GAL16V8AZ=$1A
#ATF16V8B=$80
#ATF16V8C=$81
#GAL20V8=$20
#GAL20V8AZ=$3A
#ATF20V8B=$82
#GAL6001=$40
#GAL6001B=$41
#GAL6002B=$44
#GAL22V10=$48
#GAL22V10AZ=$49
#ATF22V10B=$83
#ATF22V10C=$84
#GAL18V10=$50
#GAL18V10B=$51
#GAL26CV12=$58
#GAL26CV12B=$59
#GAL26V12C=$5D
#GAL20RA10=$60
#GAL20RA10B=$61
#GAL20XV10=$65
#GAL20XV10B=$66



;total fuses & start of user electronic signature
#FUSES16V8=2194
#UES_START16V8=2056
#FUSES20V8=2706
#UES_START20V8=2568
#FUSES18V10=3540
#UES_START18V10=3476
#FUSES22V10=5892
#UES_START22V10=5828
#FUSES26CV12=6432
#UES_START26CV12=6368
#FUSES26V12=7912
#UES_START26V12=7848
#FUSES20RA10=3274
#UES_START20RA10=3210
#FUSES20XV10=1671
#UES_START20XV10=1631
#FUSES6001=8294
#UES_START6001=8222
#FUSES6002=8330
#UES_START6002=8258

;device internal shift register width, used for detection
#SRL20XV10=46
#SRL16V8=64
#SRL20V8=64
#SRL20RA10=86
#SRL18V10=102
#SRL6001=119
#SRL26CV12=128
#SRL22V10=138
#SRL26V12=156


;Vendor
#LATTICE=$A1
#NATIONAL=$8F
#SGS_THOMSON=$20


Global Dim fusemap.a(#MAXFUSES)
Global Dim editor_fusemap.a(#MAXFUSES)
Global editor_fuses
Global fuses
Global PullUpIdent
Global FileTemp.s

Global Dim SerBuffer.a(#InBufSize)
Global Dim Message.a(#OutBufSize)
Global Dim pes.a(255) ;programmers electronic signature

Global Window_0, Fuse_Editor, Log_Editor, Splitter_0


;LoadFont(#Font_0,"Microsoft Sans Serif", 12)
;LoadFont(#Font_1,"Consolas", 12,#PB_Font_Bold)
LoadFont(#Font_2,"Consolas", 11)

DataSection
  compile_img:
  IncludeBinary "compile.png"
  ic_img:
  IncludeBinary "ic-icon.png"
EndDataSection


Procedure InitWindow_0()
  
  ExamineDesktops()
  #parentwidth=650
  parent_height=DesktopHeight(0)*0.7

  Window_0 = OpenWindow(#PB_Any, 0, 0, #parentwidth, parent_height, #APP_NAME, #PB_Window_SystemMenu|#PB_Window_SizeGadget|#PB_Window_MinimizeGadget|#PB_Window_ScreenCentered)
  If CreateMenu(0, WindowID(Window_0))
    MenuTitle("File")
    MenuItem( #MENU_OPEN, "Open...")
    MenuItem( #MENU_SAVE, "Save As...")

    MenuTitle("Device")
    MenuItem( #MENU_SET_UES, "Set User Signature")
    
    MenuItem( #MENU_COPY_PES, "Copy PES")
    MenuItem(#MENU_SECURITY,"Enable Security feature")
    MenuBar()
    MenuItem(#MENU_ATMEL_PD_DIS,"Disable ATMEL PD feature")
    MenuItem(#MENU_ATMEL_CONDITIONING,"ATMEL Conditioning")
    
    MenuTitle("Tools")
    MenuItem( #MENU_SUPPLY_TEST, "Supply test")  
    
    MenuTitle("?")
    MenuItem(#MENU_SUPPORTED_DEVICES,"Supported Devices")
    MenuItem(#MENU_ABOUT, "About")
  EndIf
  CreateToolBar(0, WindowID(Window_0),#PB_ToolBar_Text | #PB_ToolBar_Large) 
  UsePNGImageDecoder()
  
  ;LoadImage(2,GetCurrentDirectory() + "compile.png")
  ;LoadImage(3,GetCurrentDirectory() + "ic-icon.png")
  
  CatchImage(2, ?compile_img)
  CatchImage(3, ?ic_img)

  ToolBarStandardButton(#TBAR_OPEN, #PB_ToolBarIcon_Open,#PB_ToolBar_Normal,"Open")
  ToolBarToolTip(0,#TBAR_OPEN,"Open JEDEC fuse file")
  ToolBarStandardButton(#TBAR_SAVE, #PB_ToolBarIcon_Save,#PB_ToolBar_Normal,"Save")
  ToolBarToolTip(0,#TBAR_SAVE,"Safe as JEDEC fuse file")
  ToolBarSeparator()
  ToolBarImageButton(#TBAR_COMPILE, ImageID(2),#PB_ToolBar_Normal,"Compile")
  ToolBarToolTip(0,#TBAR_COMPILE,"Compile & Program")
  ToolBarSeparator()
  ToolBarImageButton(#TBAR_READ, ImageID(3),#PB_ToolBar_Normal,"Read")
  ToolBarToolTip(0,#TBAR_READ,"Read GAL")
  ToolBarImageButton(#TBAR_WRITE, ImageID(3),#PB_ToolBar_Normal,"Program")
  ToolBarToolTip(0,#TBAR_WRITE,"Program GAL")
  ToolBarImageButton(#TBAR_VERIFY, ImageID(3),#PB_ToolBar_Normal,"Verify")
  ToolBarToolTip(0,#TBAR_VERIFY,"Verify GAL")
  ToolBarImageButton(#TBAR_ERASE, ImageID(3),#PB_ToolBar_Normal,"Erase")
  ToolBarToolTip(0,#TBAR_ERASE,"Erase GAL")
  ToolBarImageButton(#TBAR_INFO, ImageID(3),#PB_ToolBar_Normal,"Info")
  ToolBarToolTip(0,#TBAR_INFO,"Pinout & OLMC configuration")
  
  CreateStatusBar(0, WindowID(Window_0))
  AddStatusBarField(#PB_Ignore)
  AddStatusBarField(#PB_Ignore)
  AddStatusBarField(#PB_Ignore)
  StatusBarProgress(0,2,0)
  
  Fuse_Editor = EditorGadget(#PB_Any, 0, 0, 0, 0, #PB_Editor_ReadOnly)
  SetGadgetFont(Fuse_Editor, FontID(#Font_2))
  Log_Editor = EditorGadget(#PB_Any, 0, 0, 0, 0, #PB_Editor_ReadOnly | #PB_Editor_WordWrap)
  SetGadgetFont(Log_Editor, FontID(#Font_2))
  Splitter_0=SplitterGadget(#PB_Any,5,ToolBarHeight(0),#parentwidth-10,parent_height-ToolBarHeight(0)-StatusBarHeight(0)-30,Fuse_Editor,Log_Editor, #PB_Splitter_Separator)
  
EndProcedure

Procedure AppendLogEntry(entry.s, type=#MSGINFO)
  
  Select type
    Case #MSGWARNING
      AddGadgetItem(Log_Editor,-1,"WARNING!")
    Case #MSGERROR
      AddGadgetItem(Log_Editor,-1,"ERROR!")
  EndSelect
  
  AddGadgetItem(Log_Editor,-1,entry)
  SendMessage_(GadgetID(Log_Editor),#EM_SCROLL,#SB_BOTTOM,0)
  
  While WindowEvent():Wend
  
EndProcedure



Procedure.a CalcVppPWM(vpp.f)
  
  ;range 10.9V < VPP < 18V
  VppPWM=Round(4045/#VREF-vpp*210/#VREF,#PB_Round_Nearest)
  
  If VppPWM<0
    ProcedureReturn 0
  ElseIf VppPWM>255
    ProcedureReturn 255
  Else
    ProcedureReturn VppPWM
  EndIf
  
EndProcedure

Procedure.f CalcVpp(vpp_pwm)
  
  ProcedureReturn (4045-vpp_pwm*#VREF)/210
  
EndProcedure


DataSection
  ACW16V8:  ; GAL16V8 ARCHITECTURE CONTROL WORD 82 fuses (LSB first)
  Data.l    2128,2129,2130,2131,2132,2133,2134,2135,2136,2137,2138,2139,2140,2141,2142,2143,
            2144,2145,2146,2147,2148,2149,2150,2151,2152,2153,2154,2155,2156,2157,2158,2159,
            2048,2049,2050,2051,  2193, 2120,2121,2122,2123,2124,2125,2126,2127,  2192, 2052,2053,2054,2055,
            2160,2161,2162,2163,2164,2165,2166,2167,2168,2169,2170,2171,2172,2173,2174,2175,
            2176,2177,2178,2179,2180,2181,2182,2183,2184,2185,2186,2187,2188,2189,2190,2191
  
  ACW16V8AZ:; GAL16V8A/B/../Z ARCHITECTURE CONTROL WORD 82 fuses (LSB first)
  Data.l    2048,2049,2050,2051,  2193, 2120,2121,2122,2123,
            2128,2129,2130,2131,2132,2133,2134,2135,2136,2137,2138,2139,2140,2141,2142,2143,
            2144,2145,2146,2147,2148,2149,2150,2151,2152,2153,2154,2155,2156,2157,2158,2159,
            2160,2161,2162,2163,2164,2165,2166,2167,2168,2169,2170,2171,2172,2173,2174,2175,
            2176,2177,2178,2179,2180,2181,2182,2183,2184,2185,2186,2187,2188,2189,2190,2191,
            2124,2125,2126,2127,  2192, 2052,2053,2054,2055
  
  ACW18V10: ; GAL18V10 ARCHITECTURE CONTROL WORD 20 fuses (LSB first)
  Data.l   3457,3456,  3459,3458,  3461,3460,  3463,3462,  3465,3464,
           3467,3466,  3469,3468,  3471,3470,  3473,3472,  3475,3474
  
  ACW20V8:  ; GAL20V8 ARCHITECTURE CONTROL WORD 82 fuses (LSB first)
  Data.l    2640,2641,2642,2643,2644,2645,2646,2647,2648,2649,2650,2651,2652,2653,2654,2655,
            2656,2657,2658,2659,2660,2661,2662,2663,2664,2665,2666,2667,2668,2669,2670,2671,
            2560,2561,2562,2563,  2705, 2632,2633,2634,2635,2636,2637,2638,2639,  2704, 2564,2565,2566,2567,
            2672,2673,2674,2675,2676,2677,2678,2679,2680,2681,2682,2683,2684,2685,2686,2687,
            2688,2689,2690,2691,2692,2693,2694,2695,2696,2697,2698,2699,2700,2701,2702,2703
  
  
  ACW20V8AZ:; GAL20V8A/B/../Z ARCHITECTURE CONTROL WORD 82 fuses (LSB first)
  Data.l    2560,2561,2562,2563,  2705, 2632,2633,2634,2635,
            2640,2641,2642,2643,2644,2645,2646,2647,2648,2649,2650,2651,2652,2653,2654,2655,
            2656,2657,2658,2659,2660,2661,2662,2663,2664,2665,2666,2667,2668,2669,2670,2671,
            2672,2673,2674,2675,2676,2677,2678,2679,2680,2681,2682,2683,2684,2685,2686,2687,
            2688,2689,2690,2691,2692,2693,2694,2695,2696,2697,2698,2699,2700,2701,2702,2703,
            2636,2637,2638,2639,  2704, 2564,2565,2566,2567
  
  ACW22V10: ; GAL22V10 ARCHITECTURE CONTROL WORD 20 fuses (LSB first)
  Data.l    5809,5808,  5811,5810,  5813,5812,  5815,5814,  5817,5816,
            5819,5818,  5821,5820,  5823,5822,  5825,5824,  5827,5826
  
  ACW20RA10:; GAL20RA10 ARCHITECTURE CONTROL WORD 10 fuses (LSB first)
  Data.l    3200,3201,3202,3203,3204,3205,3206,3207,3208,3209
  
  ACW20XV10:; GAL20XV10 ARCHITECTURE CONTROL WORD 31 fuses (LSB first)
  Data.l    1630,    1628,1629,    1620,1621,1622,    1610,1611,1612,1613,1614,    1600,1601,1602,1603,1604,
            1627,1626,    1623,1624,1625,    1619,1618,1617,1616,1615,    1609,1608,1607,1606,1605
  
  ACW26CV12:; GAL26CV12 ARCHITECTURE CONTROL WORD 24 fuses (LSB first)
  Data.l    6345,6344,    6347,6346,    6349,6348,    6351,6350,    6353,6352,    6355,6354,
            6357,6356,    6359,6358,    6361,6360,    6363,6362,    6365,6364,    6367,6366
  
  ACW26V12: ; GAL26V12 ARCHITECTURE CONTROL WORD 48 fuses (LSB first)
  Data.l    7836,7824,7812,7800, 7837,7825,7813,7801, 7838,7826,7814,7802, 7839,7827,7815,7803, 
            7840,7828,7816,7804, 7841,7829,7817,7805, 7842,7830,7818,7806, 7843,7831,7819,7807, 
            7844,7832,7820,7808, 7845,7833,7821,7809, 7846,7834,7822,7810, 7847,7835,7823,7811
 
  
  ACW6001:  ; GAL6001 ARCHITECTURE CONTROL WORD 68 fuses (LSB first)
  Data.l    8221,8220,
            8179,8183,8187,8191,8195,8199,8203,8207,8211,8215,  8214,8210,8206,8202,8198,8194,8190,8186,8182,8178,
            8216,8217,8212,8213,8208,8209,8204,8205,8200,8201,  8196,8197,8192,8193,8188,8189,8184,8185,8180,8181,
            8156,8159,8162,8165,8168,8171,8174,8177,            8154,8157,8160,8163,8166,8169,8172,8175,
            8176,8173,8170,8167,8164,8161,8158,8155,    
            8218,8219
  
  ACW6002:  ; GAL6002 ARCHITECTURE CONTROL WORD 104 fuses (LSB first)
  Data.l    8257,8256,
            8179,8183,8187,8191,8195,8199,8203,8207,8211,8215,    8214,8210,8206,8202,8198,8194,8190,8186,8182,8178,
            8216,8217,8212,8213,8208,8209,8204,8205,8200,8201,    8196,8197,8192,8193,8188,8189,8184,8185,8180,8181,
            8255,8254,8253,8252,8251,8250,8249,8248,8247,         8246,8245,8244,8243,8242,8241,8240,8239,8238,
            8220,8221,8222,8223,8224,8225,8226,8227,8228,         8229,8230,8231,8232,8233,8234,8235,8236,8237,
            8156,8159,8162,8165,8168,8171,8174,8177,              8154,8157,8160,8163,8166,8169,8172,8175,
            8176,8173,8170,8167,8164,8161,8158,8155,
            8218,8219
  
EndDataSection



Structure GAL_Struct
  ;Row is applied to RA[5..0] pins
  ;'Width' unit is bits
  ;"Adr" software address in bit-stream used on ROW RA[5..0] if Adr<>-1
  ID.l                ;device ID
  Ident.s             ;e.g. GAL16V8, ATF22V10C
  Vendor.s            ;ATMEL, LATTICE etc.
  AdrWidth.a          ;bits used for row address in bit-stream
  AdrBitOrder.a       ;0->LSB first, 1->MSB first
  Pins.a              ;DIL package only
  FusesTotal.l
  FuseMapRows.a       ;AND ARRAY only
  FuseMapRowWidth.a
  UES_Row.a
  UES_SubAdr.l
  UES_FirstFuseNo.l
  UES_Bytes.a
  UES_Offset.a        ;offset in bits
  PES_Row.a
  PES_SubAdr.l
  PES_Offset.a
  ACW_Row.a
  ACW_SubAdr.l
  ACW_RowWidth.a
  ACW.l[#MAX_ACW_FUSES]
  SecurityRow.a
  SecuritySubAdr.l
  SecurityBit.a
  BulkEraseRow.a
  BulkEraseBit.a
  EraseAllRow.a
  EraseAllBit.a
  EraseTime.l           ;max 1000ms
  ProgTime.a            ;max 255ms
  VCC.a                 ;8-bit PWM
  VPP.a                 ;8-bit PWM
  VPP_READ.a            ;8-bit PWM
  PinOut.l[#MAX_PINS+1]
  
EndStructure



Global GAL.GAL_struct

Procedure Init_GAL_Struct(gal_ID.a)
  ;ResetStructure(@GAL,GAL_struct)
  valid_device=#True
  With GAL
    \ID=gal_ID
    Select GAL\ID
      Case #GAL16V8, #GAL16V8AZ, #ATF16V8B, #ATF16V8C
        Select GAL\ID
          Case #GAL16V8
            Restore  ACW16V8
            \Ident="GAL16V8"
          Case #GAL16V8AZ
            Restore  ACW16V8AZ
            \Ident="GAL16V8AZ"
          Case #ATF16V8B
            Restore  ACW16V8AZ
            \Ident="ATF16V8B"      ;dummy
           Case #ATF16V8C
            Restore  ACW16V8AZ
            \Ident="ATF16V8C"      ;dummy
        
        EndSelect 
        
        \AdrWidth=0
        \AdrBitOrder=0
        \Pins= 20 
        \FusesTotal=#FUSES16V8
        \FuseMapRows=32
        \FuseMapRowWidth=64
        \UES_Row=32
        \UES_SubAdr=255
        \UES_FirstFuseNo=#UES_START16V8
        \UES_Bytes=8
        \UES_Offset=0
        \PES_Row=58
        \PES_SubAdr=255
        \PES_Offset=0
        \ACW_Row=60
        \ACW_SubAdr=255
        \ACW_RowWidth=82
        \SecurityRow=61
        \SecuritySubAdr=255
        \SecurityBit=1
        \BulkEraseRow=63
        \BulkEraseBit=1
        \EraseAllRow=62;also:57
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_GND
        GAL\PinOut[11]=#PIN_FUNC_I_OE
        GAL\PinOut[12]=#PIN_FUNC_I_O
        GAL\PinOut[13]=#PIN_FUNC_I_O
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_VCC
        
      Case #GAL18V10
        Restore  ACW18V10
        \Ident="GAL18V10"     
        \AdrWidth=6
        \AdrBitOrder=0
        \Pins= 20 
        \FusesTotal=#FUSES18V10
        \FuseMapRows=36
        \FuseMapRowWidth=96
        \UES_Row=0 ; GALBLAST:wrong (36)
        \UES_SubAdr=44
        \UES_FirstFuseNo=#UES_START18V10
        \UES_Bytes=8
        \UES_Offset=0
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=20
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=1
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=60
        \EraseAllBit=0
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_I_O
        GAL\PinOut[10]=#PIN_FUNC_GND
        GAL\PinOut[11]=#PIN_FUNC_I_O
        GAL\PinOut[12]=#PIN_FUNC_I_O
        GAL\PinOut[13]=#PIN_FUNC_I_O
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_VCC
        
        
      Case #GAL20V8, #GAL20V8AZ, #ATF20V8B
        Select GAL\ID
          Case #GAL20V8
            Restore  ACW20V8
            \Ident="GAL20V8"
          Case #GAL20V8AZ
            Restore  ACW20V8AZ
            \Ident="GAL20V8AZ"
          Case #ATF20V8B
            Restore  ACW20V8AZ
            \Ident="ATF20V8"      ;dummy
        EndSelect 
        
        \AdrWidth=0
        \AdrBitOrder=0
        \Pins= 24
        \FusesTotal=#FUSES20V8
        \FuseMapRows=40
        \FuseMapRowWidth=64
        \UES_Row=40
        \UES_SubAdr=255
        \UES_FirstFuseNo=#UES_START20V8
        \UES_Bytes=8
        \UES_Offset=0
        \PES_Row=58
        \PES_SubAdr=255
        \PES_Offset=0
        \ACW_Row=60
        \ACW_SubAdr=255
        \ACW_RowWidth=82
        \SecurityRow=61
        \SecuritySubAdr=255
        \SecurityBit=1
        \BulkEraseRow=63
        \BulkEraseBit=1
        \EraseAllRow=62; also:57
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_I_OE
        GAL\PinOut[14]=#PIN_FUNC_INP
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_INP
        GAL\PinOut[24]=#PIN_FUNC_VCC
        
      Case #GAL20RA10,#GAL20RA10B
        Select GAL\ID
          Case #GAL20RA10
            \Ident="GAL20RA10"
          Case #GAL20RA10B
            \Ident="GAL20RA10B"
        EndSelect 
        Restore  ACW20RA10
        \AdrBitOrder=0
        \AdrWidth=6
        \Pins= 24
        \FusesTotal=#FUSES20RA10
        \FuseMapRows=40
        \FuseMapRowWidth=80
        \UES_Row=0
        \UES_SubAdr=40
        \UES_FirstFuseNo=#UES_START20RA10
        \UES_Offset=0
        \UES_Bytes=8
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=10
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=0
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=62
        \EraseAllBit=0
        GAL\PinOut[1]=#PIN_FUNC_PL
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_OE
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_VCC
        
       Case #GAL20XV10,#GAL20XV10B
        Select GAL\ID
          Case #GAL20XV10
            \Ident="GAL20XV10"
          Case #GAL20XV10B
            \Ident="GAL20XV10B"
        EndSelect 
        Restore  ACW20XV10
        \AdrBitOrder=0
        \AdrWidth=6
        \Pins= 24
        \FusesTotal=#FUSES20XV10
        \FuseMapRows=40
        \FuseMapRowWidth=40
        \UES_Row=0
        \UES_SubAdr=44
        \UES_FirstFuseNo=#UES_START20XV10
        \UES_Offset=0
        \UES_Bytes=5
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=31
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=0
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=62
        \EraseAllBit=0
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_I_OE
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_VCC
        
      Case #GAL22V10, #GAL22V10AZ, #ATF22V10C, #ATF22V10B
        Restore  ACW22V10
        Select GAL\ID
          Case #GAL22V10
            \Ident="GAL22V10"
            \AdrBitOrder=0
            \UES_Offset=0
          Case #GAL22V10AZ
            \Ident="GAL22V10AZ"
            \AdrBitOrder=0
            \UES_Offset=0
          Case #ATF22V10B
            \Ident="ATF22V10B"
            \AdrBitOrder=0
            \UES_Offset=68
          Case #ATF22V10C
            \Ident="ATF22V10C"
            \AdrBitOrder=1
            \UES_Offset=68
        EndSelect
        
        \AdrWidth=6
        \Pins= 24
        \FusesTotal=#FUSES22V10
        \FuseMapRows=44
        \FuseMapRowWidth=132
        \UES_Row=0
        \UES_SubAdr=44
        \UES_FirstFuseNo=#UES_START22V10
        \UES_Bytes=8
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=20
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=0
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=62
        \EraseAllBit=0
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_INP
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_VCC        
        
        
      Case #GAL26CV12, #GAL26CV12B
        Restore ACW26CV12
        Select GAL\ID
          Case #GAL26CV12
            \Ident="GAL26CV12"
          Case #GAL26CV12B
            \Ident="GAL26CV12B"
        EndSelect 
        
        \AdrWidth=6
        \AdrBitOrder=0
        \Pins= 28
        \FusesTotal=#FUSES26CV12
        \FuseMapRows=52
        \FuseMapRowWidth=122
        \UES_Row=0
        \UES_SubAdr=52
        \UES_FirstFuseNo=#UES_START26CV12
        \UES_Bytes=8
        \UES_Offset=0
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=24
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=1
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=57
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_VCC
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_INP
        GAL\PinOut[13]=#PIN_FUNC_INP
        GAL\PinOut[14]=#PIN_FUNC_INP
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_GND
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_I_O
        GAL\PinOut[25]=#PIN_FUNC_I_O
        GAL\PinOut[26]=#PIN_FUNC_I_O
        GAL\PinOut[27]=#PIN_FUNC_I_O
        GAL\PinOut[28]=#PIN_FUNC_INP
        
       Case #GAL26V12C
        Restore ACW26V12
        \Ident="GAL26V12C"
        \AdrWidth=6
        \AdrBitOrder=0
        \Pins= 28
        \FusesTotal=#FUSES26V12
        \FuseMapRows=52
        \FuseMapRowWidth=150
        \UES_Row=0
        \UES_SubAdr=52
        \UES_FirstFuseNo=#UES_START26V12
        \UES_Bytes=8
        \UES_Offset=0
        \PES_Row=0
        \PES_SubAdr=58
        \PES_Offset=0
        \ACW_Row=16
        \ACW_SubAdr=255
        \ACW_RowWidth=48
        \SecurityRow=0
        \SecuritySubAdr=61
        \SecurityBit=1
        \BulkEraseRow=61
        \BulkEraseBit=0
        \EraseAllRow=57
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_I_CLK2
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_VCC
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_INP
        GAL\PinOut[13]=#PIN_FUNC_INP
        GAL\PinOut[14]=#PIN_FUNC_INP
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_GND
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_I_O
        GAL\PinOut[25]=#PIN_FUNC_I_O
        GAL\PinOut[26]=#PIN_FUNC_I_O
        GAL\PinOut[27]=#PIN_FUNC_I_O
        GAL\PinOut[28]=#PIN_FUNC_INP
        
      Case #GAL6001,#GAL6001B
        Restore ACW6001
        Select GAL\ID
          Case #GAL6001
            \Ident="GAL6001"
          Case #GAL6001B
            \Ident="GAL6001B"
        EndSelect 
        
        \AdrWidth=24
        \AdrBitOrder=0
        \Pins= 24
        \FusesTotal=#FUSES6001
        \FuseMapRows=78
        \FuseMapRowWidth=95
        \UES_Row=0
        \UES_SubAdr=(97<<1)+1
        \UES_FirstFuseNo=#UES_START6001
        \UES_Bytes=9
        \UES_Offset=20
        \PES_Row=0
        \PES_SubAdr=(96<<1)+1
        \PES_Offset=20
        \ACW_Row=8
        \ACW_SubAdr=255
        \ACW_RowWidth=68
        \SecurityRow=0
        \SecuritySubAdr=(98<<1)+1
        \SecurityBit=1
        \BulkEraseRow=63
        \BulkEraseBit=1
        \EraseAllRow=59
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_OCLK
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_VCC 
        
      Case #GAL6002B
        Restore ACW6002
        \Ident="GAL6002B"
        \AdrWidth=24
        \AdrBitOrder=0
        \Pins= 24
        \FusesTotal=#FUSES6002
        \FuseMapRows=78
        \FuseMapRowWidth=95
        \UES_Row=0
        \UES_SubAdr=(97<<1)+1
        \UES_FirstFuseNo=#UES_START6002
        \UES_Bytes=9
        \UES_Offset=20
        \PES_Row=0
        \PES_SubAdr=(96<<1)+1
        \PES_Offset=20
        \ACW_Row=8
        \ACW_SubAdr=255
        \ACW_RowWidth=104
        \SecurityRow=0
        \SecuritySubAdr=(98<<1)+1
        \SecurityBit=1
        \BulkEraseRow=63
        \BulkEraseBit=1
        \EraseAllRow=59
        \EraseAllBit=1
        GAL\PinOut[1]=#PIN_FUNC_I_CLK
        GAL\PinOut[2]=#PIN_FUNC_INP
        GAL\PinOut[3]=#PIN_FUNC_INP
        GAL\PinOut[4]=#PIN_FUNC_INP
        GAL\PinOut[5]=#PIN_FUNC_INP
        GAL\PinOut[6]=#PIN_FUNC_INP
        GAL\PinOut[7]=#PIN_FUNC_INP
        GAL\PinOut[8]=#PIN_FUNC_INP
        GAL\PinOut[9]=#PIN_FUNC_INP
        GAL\PinOut[10]=#PIN_FUNC_INP
        GAL\PinOut[11]=#PIN_FUNC_INP
        GAL\PinOut[12]=#PIN_FUNC_GND
        GAL\PinOut[13]=#PIN_FUNC_OCLK
        GAL\PinOut[14]=#PIN_FUNC_I_O
        GAL\PinOut[15]=#PIN_FUNC_I_O
        GAL\PinOut[16]=#PIN_FUNC_I_O
        GAL\PinOut[17]=#PIN_FUNC_I_O
        GAL\PinOut[18]=#PIN_FUNC_I_O
        GAL\PinOut[19]=#PIN_FUNC_I_O
        GAL\PinOut[20]=#PIN_FUNC_I_O
        GAL\PinOut[21]=#PIN_FUNC_I_O
        GAL\PinOut[22]=#PIN_FUNC_I_O
        GAL\PinOut[23]=#PIN_FUNC_I_O
        GAL\PinOut[24]=#PIN_FUNC_VCC 
      Default
        valid_device=#False
    EndSelect
    
    If valid_device=#True
      For n=1 To GAL\ACW_RowWidth
        Read.l fuse
        GAL\ACW[n-1]=fuse
      Next n
    EndIf
    
  EndWith
  ProcedureReturn valid_device
  
EndProcedure

Procedure.s GetPinOLMCConfig(OLMC_pin.a)
  
  #REGISTER=1
  #SIMPLE=2
  #COMPLEX=3

  Select gal\ID
    Case #GAL16V8,#GAL16V8AZ,#ATF16V8B,#ATF16V8C,#GAL20V8,#GAL20V8AZ,#ATF20V8B
      Select gal\ID
        Case #GAL16V8,#GAL16V8AZ,#ATF16V8B,#ATF16V8C
          start_pin=12
          start_pin_ac1=2127
          galmode=editor_fusemap(2192)*2+editor_fusemap(2193); SYN,AC0
        Case #GAL20V8,#GAL20V8AZ,#ATF20V8B
          start_pin=15
          start_pin_ac1=2639
          galmode=editor_fusemap(2704)*2+editor_fusemap(2705); SYN,AC0
      EndSelect
      
      If OLMC_pin=start_pin
        Select galmode
          Case 0
            AppendLogEntry("Mode not defined!; SYN=0, AC0=0")
          Case #REGISTER
            AppendLogEntry("Registered Mode; SYN=0, AC0=1; /OE & CLK are dedicated inputs")
          Case #SIMPLE
            AppendLogEntry("Simple Mode; SYN=1, AC0=0")
            If gal\ID=#GAL16V8 Or gal\ID=#GAL20V8
              AppendLogEntry("CAUTION! Early GAL revision. All outputs without feedback!")
            EndIf
          Case #COMPLEX
            AppendLogEntry("Complex Mode; SYN=1, AC0=1")
        EndSelect
      EndIf
      
      
      n=OLMC_pin-start_pin
      pin_func$="not defined!"
      Select galmode*2+editor_fusemap(start_pin_ac1-n) ;pin mode
        Case #REGISTER*2
          pin_func$="REGISTER; TRI-STATE by /OE"
        Case #REGISTER*2+1
          pin_func$="TRI-STATE by Product Term"
        Case #SIMPLE*2
          If n=3 Or n=4
            pin_func$="OUTPUT (NO feedback!)"
          Else
            If gal\ID=#GAL16V8 Or gal\ID=#GAL20V8
              pin_func$="OUTPUT (NO feedback!)"
            Else
              pin_func$="OUTPUT"
            EndIf
          EndIf
        Case #SIMPLE*2+1
          If Not(n=3 Or n=4)
            pin_func$="INPUT"
          EndIf
        Case #COMPLEX*2+1
          If n=0 Or n=7
            pin_func$="TRI-STATE (NO feedback!) by Product Term" 
          Else
            pin_func$="TRI-STATE by Product Term"
          EndIf
      EndSelect
      
    Case #GAL22V10, #GAL22V10AZ, #ATF22V10B, #ATF22V10C
      start_pin=14
      start_pin_s1=5827
      If editor_fusemap(start_pin_s1-2*(OLMC_pin-start_pin))=0
        pin_func$="REGISTERED" 
      Else
        pin_func$="COMBINATORIAL"
      EndIf
  EndSelect
  
  ProcedureReturn pin_func$
    
EndProcedure
Procedure GetPinoutFromDoc()
  
  If ReadFile(0,GetPathPart(FileTemp)+GetFilePart(FileTemp,#PB_FileSystem_NoExtension)+".doc")
    result=0 
    While Eof(0) = 0 And result=0 
      result=FindString(ReadString(0),"|           -----           |")
    Wend
    AppendLogEntry(Space(25)+" ___________     ___________")
    AppendLogEntry(Space(25)+"|           \___/           |")
    result=0
    While Eof(0) = 0 And result=0
      fileline$=ReadString(0)
      result=FindString(fileline$,"`---")
      If result=0
        If FindString(fileline$,"|                           |")=0
          AppendLogEntry(fileline$)
        EndIf
      Else
        AppendLogEntry(Space(25)+"|___________________________|")
      EndIf
    Wend
    CloseFile(0)
  EndIf
  
EndProcedure

Procedure DrawPinout()
  
  #REGISTER=1
  
  If gal\Pins=0:ProcedureReturn:EndIf
  
  Dim PinFunc$(gal\Pins)
  
  For pin=1 To gal\Pins
    Select gal\PinOut[pin]
      Case #PIN_FUNC_INP
        PinFunc$(pin)="I"
      Case #PIN_FUNC_GND
        PinFunc$(pin)="GND"
      Case  #PIN_FUNC_VCC
        PinFunc$(pin)="VCC"
      Case #PIN_FUNC_I_CLK
        PinFunc$(pin)="I_CLK"
      Case #PIN_FUNC_I_CLK2
        PinFunc$(pin)="I_CLK2"
      Case #PIN_FUNC_I_O
        PinFunc$(pin)="I/O"
      Case #PIN_FUNC_I_OE
        PinFunc$(pin)="I_/OE"
      Case #PIN_FUNC_OE
        PinFunc$(pin)="/OE"
      Case #PIN_FUNC_PL
        PinFunc$(pin)="/PL"
      Case #PIN_FUNC_OCLK
        PinFunc$(pin)="OCLK"
    EndSelect
  Next pin
  
  Select gal\ID
    Case #GAL16V8,#GAL16V8AZ,#ATF16V8B,#ATF16V8C
      For pin=12 To 19:PinFunc$(pin)=GetPinOLMCConfig(pin):Next pin
      galmode=editor_fusemap(2192)*2+editor_fusemap(2193); SYN,AC0
      If galmode=#REGISTER:PinFunc$(1)="CLK":PinFunc$(11)="/OE":EndIf
      
    Case #GAL20V8,#GAL20V8AZ,#ATF20V8B
      For pin=15 To 22:PinFunc$(pin)=GetPinOLMCConfig(pin):Next pin
      galmode=editor_fusemap(2704)*2+editor_fusemap(2705); SYN,AC0
      If galmode=#REGISTER:PinFunc$(1)="CLK":PinFunc$(13)="/OE":EndIf
      
    Case #GAL22V10, #GAL22V10AZ, #ATF22V10B, #ATF22V10C
      For pin=14 To 23:PinFunc$(pin)=GetPinOLMCConfig(pin):Next pin   
  EndSelect
  
  AppendLogEntry(Space(6)+"  _____     _____")
  AppendLogEntry(Space(6)+" |     \___/     |")
  For pin=1 To gal\Pins/2
    AppendLogEntry(RSet(PinFunc$(pin),6," ")+" | "+RSet(Str(pin),2," ")+Space(9)+RSet(Str(gal\Pins-pin+1),2," ")+" | "+PinFunc$(gal\Pins-pin+1))
  Next pin
  AppendLogEntry(Space(6)+" |_______________|")
  
EndProcedure
  	
Procedure CalcChecksum(chksumfuses)
  
  bitval=1
  For n=0 To chksumfuses-1
    checksum=checksum+editor_fusemap(n)*bitval
    bitval=bitval<<1
    If bitval=256:bitval=1:EndIf
  Next n
  ProcedureReturn checksum & $FFFF
  
EndProcedure

Procedure ParseJEDEC(fname$)
  
  error=#False
  fuses=0
  FillMemory(editor_fusemap(),#MAXFUSES+1,0)
  
  Start=ElapsedMilliseconds()
  
  If ReadFile(0, fname$)
    If Lof(0)>#MAXFILESIZE:AppendLogEntry("File size > "+Str(#MAXFILESIZE),#MSGERROR):error=#True:EndIf ;file too large
    While Eof(0) = 0  And Chr(ReadAsciiCharacter(0))<>"*": Wend                                         ;discard all until first field delimiter
    While Eof(0) = 0 And error=#False
      file_char$=UCase(Chr(ReadAsciiCharacter(0)))
      If file_char$="*" ;field delimiter -> process field
        field$=Trim(field$);:LogField(field$)
        Select Left(field$,1)
          Case "L" ;fuse field
            fusefield$=Mid(field$,FindString(field$," ")+1):fuse_adr=Val(Mid(field$,2))
            fusefieldlen=Len(fusefield$)
            For n=1 To fusefieldlen
              fieldchar$=Mid(fusefield$,n,1)
              If fieldchar$="1" Or fieldchar$="0"
                If fuse_adr<#MAXFUSES
                  editor_fusemap(fuse_adr)=Asc(fieldchar$) & 1:fuse_adr+1
                Else
                  error=#True:Break
                EndIf
              EndIf
            Next n
          Case "C" ;checksum reference field (4-digits HEX number)
            checksum_ref=Val("$"+Mid(field$,2)):
            If fuses=0
              checksum=CalcChecksum(fuse_adr) ;handle missing QF-field
            Else
              checksum=CalcChecksum(fuses)
            EndIf
            If checksum_ref<>checksum
              appendLogEntry("Checksum: "+Hex(checksum)+" <> expected: "+Hex(checksum_ref),#MSGWARNING)
            EndIf
          Default
            Select Left(field$,2)
              Case "QF" ;quantity fuses
                fuses=Val(Mid(field$,3))
                If fuses>#MAXFUSES Or fuses=0:error=#True:EndIf
              Case "QP" ;quantity pins
              Case "G1" ;Security enable
              Case "F1" ;fuse default '1'
                FillMemory(editor_fusemap(),#MAXFUSES+1,1)
            EndSelect
        EndSelect
        field$=""
      Else ;concatenate field
        If Asc(file_char$)>32
          field$= LSet(field$,Len(field$)+1,file_char$)
        Else
          field$=field$+Space(1) ;replace CR & LF with SPACE
        EndIf
      EndIf
    Wend
    Ende=ElapsedMilliseconds()
    If error=#False And fuses=0
      fuses=fuse_adr ;handle missing QF-field
    EndIf
    CloseFile(0)
    
  Else
    AppendLogEntry("Can't access file",#MSGERROR)
  EndIf
  ProcedureReturn fuses
  
EndProcedure

Procedure.s GetFileName(SaveAs.a =#False, PatternPos = 0, NameDefault.s="")
  ;uses DriveTypeNum
  
  If Cancel=#True: ProcedureReturn "":EndIf
  
  Static PrevOpenPath.s, PrevSavePath.s
  
  Select SaveAs
    Case #True
      StandardFile.s = PrevSavePath
    Case #False
      StandardFile.s = PrevOpenPath
  EndSelect
  
  If StandardFile.s = "" 
    StandardFile.s=GetCurrentDirectory()
  EndIf
  
  Pattern.s = "JEDEC file (*.jed)|*.jed|ABEL file (*.abl)|*.abl|all files (*.*)|*.*"
  
  
  Select SaveAs
    Case #True
      Repeat
        File.s = SaveFileRequester("Save as", StandardFile+NameDefault, Pattern, PatternPos)
        If File<>"" And GetExtensionPart(File)=""
          Select SelectedFilePattern()
            Case 0
              File=File+".jed"
          EndSelect
        EndIf
        result=#PB_MessageRequester_Yes
        If FileSize(File) <>-1
          Message.s="Replace "+Chr(34)+GetFilePart(File)+Chr(34)+"?"
          result=MessageRequester("File already exists",Message,#PB_MessageRequester_YesNo|$100|$30)
        EndIf 
      Until result=#PB_MessageRequester_Yes 
      If File <> ""
        PrevSavePath=GetPathPart(File)
      Else
        AppendLogEntry ("Save canceled")
      EndIf
    Case #False
      File.s = OpenFileRequester("Open", StandardFile, Pattern, PatternPos)
      If File <> ""
        PrevOpenPath=GetPathPart(File)
      EndIf
  EndSelect
  
  ProcedureReturn File
  
EndProcedure

Procedure CompileABEL(fname$)
  
  If fname$<>""
    #abel_file_name="abelcpl"
    #file_error_msg="ERROR: "
    vDosPath$=GetCurrentDirectory()+"vDosPlus\"
    
    If ReadFile(0, fname$)
      If CreateFile(1, vDosPath$+"\abel\"+#abel_file_name+".abl")
        
        While Eof(0) = 0 And result=0 
          result=FindString( UCase(ReadString(0)),"MODULE")
        Wend
        If result<>0
          WriteStringN(1,"MODULE "+#abel_file_name)
          result=0
        EndIf
        
        While Eof(0) = 0 And result=0
          fileline$=ReadString(0)
          result=FindString( UCase(fileline$),"DEVICE")
          If result=0
            WriteStringN(1,fileline$)
          EndIf
        Wend    
        
        If result<>0
          WriteStringN(1,#abel_file_name+" DEVICE"+Mid(fileline$,result+Len("DEVICE")))
          result=0
        EndIf
        
        While Eof(0) = 0 
          WriteStringN(1,ReadString(0))
        Wend
        
        CloseFile(0)  :CloseFile(1)
        DeleteFile(vDosPath$+"\abel\"+#abel_file_name+".out")
        DeleteFile(vDosPath$+"\abel\"+#abel_file_name+".jed")
        DeleteFile(vDosPath$+"\abel\"+#abel_file_name+".doc")
        DeleteFile(vDosPath$+"\abel\"+#abel_file_name+".sim")
        If RunProgram(vDosPath$+"vDosPlus.exe","",vDosPath$,#PB_Program_Wait | #PB_Program_Hide)
          fname$=GetPathPart(fname$)+GetFilePart(fname$,#PB_FileSystem_NoExtension)
          
          If ReadFile(0, vDosPath$+"\abel\"+#abel_file_name+".out")  
            ClearGadgetItems(Log_Editor)
            
            While Eof(0) = 0 
              AddGadgetItem(Log_Editor,-1,ReadString(0))
            Wend
            
            CloseFile(0) 
            CopyFile(vDosPath$+"\abel\"+#abel_file_name+".out",fname$+".out")
            CopyFile(vDosPath$+"\abel\"+#abel_file_name+".doc",fname$+".doc")
            CopyFile(vDosPath$+"\abel\"+#abel_file_name+".sim",fname$+".sim")
            If CopyFile(vDosPath$+"\abel\"+#abel_file_name+".jed",fname$+".jed")=#True
              ProcedureReturn #True
            EndIf
          Else
            AppendLogEntry(#file_error_msg+"Can't open compiler output file!")
          EndIf
        Else
          AppendLogEntry(#file_error_msg+"Can't start vDosPlus")
        EndIf
      Else
        AppendLogEntry(#file_error_msg+"Can't duplicate ABEL design file!")
      EndIf
    Else
      AppendLogEntry(#file_error_msg+"Can't open ABEL design file!")
    EndIf
  EndIf
  ProcedureReturn #False
  
EndProcedure


Procedure SendMessage( message_len.l, return_len=16, timout_sec.a=4)
  
  ; If ErrorLevel>#ERR_IEC:ProcedureReturn:EndIf
  timeout_ms=timout_sec*1000
  SetSerialPortStatus(0,#PB_SerialPort_TXD,1)
  Delay(1)
  SetSerialPortStatus(0,#PB_SerialPort_TXD,0)
  Delay(1)
  While AvailableSerialPortInput(0)<>0
    ReadSerialPortData(0, @SerBuf.s{1}, 1)
  Wend
  WriteSerialPortData (0,@Message(0),message_len)
  
  While (AvailableSerialPortInput(0)<return_len+4) And ErrorLevel<#ERR_ATMEGA
    While WindowEvent():Wend
    Delay(1)
    timeout_ms=timeout_ms-1
    If  timeout_ms=0
      AppendLogEntry("Connection Timeout")
      ErrorLevel = #ERR_ATMEGA
    EndIf
  Wend
  
  
  If AvailableSerialPortInput(0)>3 And AvailableSerialPortInput(0)<#InBufSize
    ReDim SerBuffer(AvailableSerialPortInput(0))
    ReadSerialPortData(0, @SerBuffer(0), AvailableSerialPortInput(0))
    If SerBuffer(ArraySize(SerBuffer())-1)=Message(0)
      payload=SerBuffer(ArraySize(SerBuffer())-4)+256*SerBuffer(ArraySize(SerBuffer())-3)
      If payload>0
        ReDim SerBuffer(payload-1)
      EndIf
    Else
      AppendLogEntry("Response Error")
    EndIf
  EndIf
  
  ProcedureReturn payload
  
EndProcedure
Procedure SupplyTest()
  
  msg$="Supply test"
  inp$=InputRequester(msg$,"Input [VCC>3.3V],[VPP>11V]; e.g. '5, 12.5'","")
  If inp$="" :ProcedureReturn:EndIf
  AppendLogEntry(Chr(13)+msg$)
  AppendLogEntry("Given values:")
  AppendLogEntry("Vcc: "+StringField(inp$,1,",")+"V")
  AppendLogEntry("Vpp: "+StringField(inp$,2,",")+"V")
  VppPWM.a=CalcVppPWM(ValF(StringField(inp$,2,",")))
  VccPWM.a=Round(256/#VREF*ValF(inp$),#PB_Round_Up)
  AppendLogEntry("Calculated set values:")
  AppendLogEntry("Vcc @ pin24  = "+StrF(#VREF/256*VccPWM,2))
  AppendLogEntry("Vpp @ pin2   = "+StrF(CalcVpp(VppPWM),2))
  AppendLogEntry("GND @ pin12")
  Message(0)= 1 ;POWER-UP
  Message(1)= 7 ;message length
  Message(2)=VccPWM ;VCC
  Message(3)=VppPWM ;VPP                 
  Message(4)= 0
  Message(5)= 24 ;24-pin
  Message(6)=0 ;no VPP ramp-up
  SendMessage(Message(1))
  
  MessageRequester(msg$,"Click OK to end the test")
  
  Message(0)= 2 ;SHUT-DOWN
  Message(1)= 2 ;message length
  SendMessage(Message(1))
      
EndProcedure

Procedure SetProgrammingAlgo()
  
  ;*** PES byte B0  ***
  ;b0(LSB)..b7(MSB) number of times GAL was programmed (If set by programmer)
  ;*** PES byte B1  ***
  ;b8..b11=byte programming algorithm, interpret depending of GAL type
  ;    16V8 20RA10
  ;    20V8 20XV10
  ;    6001 22V10
  ;    6002 18V10
  ;         26CV12
  ;     00   01    VPP 15.75V programming pulse 100ms
  ;     01         VPP 15.75V programming pulse 80ms
  ;     02   00    VPP 16.50V programming pulse 10ms
  ;     03   02    VPP 14.50V (National 15.00V) programming pulse 40ms
  ;     04   03    VPP 14.00V programming pulse 100ms
  ;     05   05    definitions stored at bit 32 (B4)
  ; erase pulse time 10,25,50,100,200,400,800,- msec (only if B1=0x05), 
  ; else For 6001, 6002, National 20RA10, 20XV10, 22V10, 18V10, 26CV12: 50 msec, Else 100 msec
  ;b12=LOW-VOLTAGE-bit (0 For Normal 5V GAL, 1 For 3.3 low-voltage GAL)
  ;b15=MASTER-bit (modify GAL only after query of user)
  
  ;*** PES byte B2  ***
  ;b16..b23 GAL type (see GAL IDs above)
  
  gal\VCC=Round(256/#VREF*#VCC,#PB_Round_Up)
  Select gal\ID
    Case #ATF16V8B, #ATF16V8C, #ATF20V8B, #ATF22V10B, #ATF22V10C; ATMEL
      If gal\ID=#ATF16V8C Or gal\ID=#ATF22V10C 
        gal\ProgTime=20
        gal\EraseTime=200
      Else
        gal\ProgTime=10
        gal\EraseTime=100
      EndIf
      gal\VPP=CalcVppPWM(12)
      gal\VPP_READ=gal\VPP
      gal\Vendor="ATMEL"
     
    Default 
      ;Else ;  none ATMEL
      ;*** PES byte B3  ***
      ;b24..b31
      Select pes(3) ;vendor
        Case #LATTICE
          gal\Vendor="LATTICE"
        Case #NATIONAL
          gal\Vendor="NATIONAL"
        Case #SGS_THOMSON
          gal\Vendor="ST"
        Default
          gal\Vendor="???"
      EndSelect
      
      prog_algo.a=pes(1) & 7
      
      If prog_algo=5
        ;*** PES byte B4, B5 & B6  ***
        ;b32..b33: ignored
        ;b34..b36: erase pulse time 10,25,50,100,200,400,800,- msec (only If B1=0x05), Else For 6001, 6002, National 20RA10, 20XV10, 22V10, 18V10, 26CV12: 50 msec, Else 100 msec
        ;b37..b40: programing pulse time 1,2,5,10,20,30,40,50,60,70,80,90,100,200,-,- msec
        ;b41..b45: VPP(program/erase) 5.0,5.5,6.0,...20.5V
        ;b46..b50: VPP(readout) 5.0,5.5,6.0,...20.5V (always 12V)
        ;b56..b63: check sum 
        
        ;erase timing (3 bits)
        algo5_data.a=(pes(4)>>2) & 7
        gal\EraseTime= Int(Pow(2,algo5_data)*12.5)
        ;prog timing (4 bits)
        algo5_data=((pes(5) & 1)<<3) | (pes(4)>>5)
        Select algo5_data
          Case 0
            gal\ProgTime=1
          Case 1
            gal\ProgTime=2
          Case 2
            gal\ProgTime=5
          Case 3 To 12
            gal\ProgTime=(algo5_data-2)*10
          Case 13 To 15
            gal\ProgTime=200
        EndSelect
        
        ;VPP (5 bits)
        algo5_data.a=(pes(5)>>1) & 31
        gal\VPP=CalcVppPWM(5+algo5_data*0.5)
        ;VPP_read (5 bits)
        algo5_data=(pes(5)>>6)
        algo5_data=((pes(6)<<2) | algo5_data) & 31
        gal\VPP_READ=CalcVppPWM(5+algo5_data*0.5)
        
      Else
        Select gal\ID
          Case #GAL16V8,#GAL16V8AZ,#GAL20V8,#GAL20V8AZ, #GAL6001,#GAL6001B,#GAL6002B
            Select gal\ID
              Case #GAL6001,#GAL6001B,#GAL6002B
                gal\EraseTime=50
              Default
                gal\EraseTime=100
            EndSelect
            
            Select (prog_algo)
              Case 0
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(15.75)
              Case 1
                gal\ProgTime=80;
                gal\VPP=CalcVppPWM(15.75)
              Case 2
                ;GALxxV8AS [ST] fails at high dv/dt -> ramp 12V < VPP < 16.5V
                gal\ProgTime=10;
                gal\VPP=CalcVppPWM(16.5)
              Case 3
                gal\ProgTime=40;
                If pes(3)=#NATIONAL
                  gal\VPP=CalcVppPWM(15) 
                Else
                  gal\VPP=CalcVppPWM(14.5)
                EndIf
              Case 4
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(15.75)
              Default
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(15)              
            EndSelect
            
          Default
            If pes(3)=#NATIONAL
              gal\EraseTime=50 
            Else
              gal\EraseTime=100
            EndIf
            Select (prog_algo)
              Case 0
                gal\ProgTime=10;
                gal\VPP=CalcVppPWM(16.5)
              Case 1
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(15.75)
              Case 2
                gal\ProgTime=40;
                If pes(3)=#NATIONAL
                  gal\VPP=CalcVppPWM(15) 
                Else
                  gal\VPP=CalcVppPWM(14.5)
                EndIf
              Case 3
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(14)
              Default
                gal\ProgTime=100;
                gal\VPP=CalcVppPWM(15)  
            EndSelect
        EndSelect
      EndIf
  EndSelect
  
EndProcedure


Procedure Read_Row(row_type, fusemap_row=0)
  
  Message(0)= 5 ;ATMEGA CMD
  Message(1)= 8 ;message length
  
  Select row_type
    Case #FUSEMAP
      Message(2)=gal\FuseMapRowWidth ;row width
      If gal\AdrWidth=0
        Message(3)=fusemap_row
        Message(4)=255
      Else
        Message(3)=0
        Message(4)=fusemap_row
      EndIf
      Message(5)=gal\AdrWidth
      Message(6)=gal\AdrBitOrder
      Message(7)=0 ;row width
      
    Case #FUSE_OR
       Message(1)=10+gal\FuseMapRowWidth+gal\AdrWidth
       Message(2)=gal\FuseMapRowWidth+gal\AdrWidth ;row width
       Message(5)=gal\AdrWidth
       Message(6)=gal\AdrBitOrder
       Message(7)=gal\FuseMapRowWidth+gal\AdrWidth ;row width (address setup)
      
    Case #UES
      Message(2)=gal\FuseMapRowWidth ;row width
      Message(3)=gal\UES_Row
      Message(4)=gal\UES_SubAdr
      Message(5)=gal\AdrWidth
      Message(6)=gal\AdrBitOrder
      Message(7)=0 ;row width
      
    Case #ACW
      Message(2)=gal\ACW_RowWidth ;row width
      Message(3)=gal\ACW_Row
      Message(4)=gal\ACW_SubAdr
      Message(5)=gal\AdrWidth
      Message(6)=gal\AdrBitOrder
      Message(7)=0 ;row width
      
    Case #PES
      Message(2)=gal\FuseMapRowWidth ;row width
      Message(3)=gal\PES_Row
      Message(4)=gal\PES_SubAdr
      Message(5)=gal\AdrWidth
      Message(6)=gal\AdrBitOrder
      Message(7)=0 ;row width
      
  EndSelect
  ProcedureReturn  SendMessage(Message(1),Message(2))
  
EndProcedure

Procedure Write_Row(row_type, fusemap_row=0, consec_rows=0)
  
  Message(0)= 7 ;ATMEGA CMD
  Message(5)=gal\AdrWidth
  Message(6)=gal\AdrBitOrder
  Message(8)=0
  Message(9)=consec_rows ;0: write single row, >0: write consecutive rows
  
  Select row_type
    Case #FUSEMAP
      Message(1)=10+gal\FuseMapRowWidth;message length
      Message(2)=gal\FuseMapRowWidth ;row width
      If gal\AdrWidth=0
        Message(3)=fusemap_row
        Message(4)=255 ;no subadr
      Else
        Message(3)=0 ;ROW=0
        Message(4)=fusemap_row
      EndIf
      Message(7)=gal\ProgTime
      
    Case #FUSE_OR ;only GAL6001 & GAL6002
       Message(1)=10+gal\FuseMapRowWidth+gal\AdrWidth
       Message(2)=gal\FuseMapRowWidth+gal\AdrWidth ;row width
       Message(3)=fusemap_row
       Message(4)=255 ;no subadr
       Message(7)=gal\ProgTime
       Message(8)=$80 ;OR flag
      
    Case #UES
      Message(1)=10+gal\FuseMapRowWidth
      Message(2)=gal\FuseMapRowWidth ;row width
      Message(3)=gal\UES_Row
      Message(4)=gal\UES_SubAdr
      Message(7)=gal\ProgTime
      
    Case #ACW
      Message(1)=10+gal\ACW_RowWidth
      Message(2)=gal\ACW_RowWidth ;row width
      Message(3)=gal\ACW_Row
      Message(4)=gal\ACW_SubAdr
      Message(7)=gal\ProgTime
      
    Case #PES
      Message(1)=10+gal\FuseMapRowWidth
      Message(2)=gal\FuseMapRowWidth ;row width
      Message(3)=gal\PES_Row
      Message(4)=gal\PES_SubAdr
      Message(7)=gal\ProgTime
      
    Case #BULKERASE
      Message(1)=11
      Message(2)=1 ;row width
      Message(3)=gal\BulkEraseRow
      Message(4)=255 ;no sub adr.
      Message(7)=gal\EraseTime & 255
      Message(8)=(gal\EraseTime / 256)  & 3
      Message(10)=gal\BulkEraseBit
      
    Case #ERASEALL
      Message(1)=11
      Message(2)=1 ;row width
      Message(3)=gal\EraseAllRow
      Message(4)=255 ;no sub adr.
      Message(7)=gal\EraseTime & 255
      Message(8)=(gal\EraseTime / 256) & 3
      Message(10)=gal\EraseAllBit
      
    Case #SECURITY
      Message(1)=11
      Message(2)=1 ;row width
      Message(2)=gal\FuseMapRowWidth ;row width
      Message(3)=gal\SecurityRow
      Message(4)=gal\SecuritySubAdr
      Message(7)=gal\ProgTime
      Message(10)=gal\SecurityBit
      
      
    Case #ATMEL_PD_DIS
            If gal\AdrWidth=0
        Message(3)=59 ;power down row
        Message(4)=255 ;no subadr
      Else
        Message(3)=0 ;ROW=0
        Message(4)=59
      EndIf
      Message(1)=11
      Message(2)=1 ;row width
      Message(7)=gal\ProgTime
      Message(10)=0 ;disable
      
  EndSelect
  ProcedureReturn  SendMessage(Message(1))
  
EndProcedure


Procedure DetectDevice(gal_type)
  
  Init_GAL_Struct(gal_type) ;generic init
  
  gal\VPP_READ=CalcVppPWM(#VPP_READ) ;VPP_read
  
  Message(0)= 1 ;POWER-UP
  Message(1)= 7 ;message length
  Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
  Message(3)=gal\VPP_READ                  
  Message(4)= gal\ID
  Message(5)= gal\Pins
  Message(6)=0 ;no VPP ramp-up
  SendMessage(Message(1))
  If ErrorLevel>0:ProcedureReturn:EndIf
  
  PullUpIdent=SerBuffer(0)
  
  Message(0)= 3 ;DETECT
  Message(1)= 2 ;message length
  SendMessage(Message(1))
  
EndProcedure

Procedure GAL_scan()
  
  found=#True
 ;step through generic pinouts and detect
  DetectDevice(#GAL16V8)
  If ErrorLevel>0:ProcedureReturn #False:EndIf

    If SerBuffer(0)=0:DetectDevice(#GAL18V10):EndIf;Else :found16v8=#True:EndIf
    If SerBuffer(0)=0:DetectDevice(#GAL20V8):EndIf
    If SerBuffer(0)=0:DetectDevice(#GAL22V10):EndIf
    If SerBuffer(0)=0:DetectDevice(#GAL6001):EndIf
    If SerBuffer(0)=0:DetectDevice(#ATF16V8C):EndIf ;ATF16V8C has different P/V setup

  Select SerBuffer(0)
      
    Case 1 ;ATMEL
      Select SerBuffer(1)
        Case #SRL16V8;64
          Init_GAL_Struct(#ATF16V8B)
        Case #SRL16V8-1;63
          Init_GAL_Struct(#ATF20V8B)
        Case #SRL22V10-1;137
          Init_GAL_Struct(#ATF22V10B)
        Default
          found=#False
      EndSelect
      
    Case #SRL16V8;64
      ;all GAL16V8, GAL20V8, ATF16V8, ATF20V8
;       If found16v8=#True
;         Init_GAL_Struct(#GAL16V8)
;       Else
;         Init_GAL_Struct(#GAL20V8)
;       EndIf
    Case #SRL18V10;102
      ;Init_GAL_Struct(#GAL18V10)
    Case #SRL20RA10;86
      Init_GAL_Struct(#GAL20RA10)
    Case #SRL20XV10;46
      Init_GAL_Struct(#GAL20XV10)
    Case #SRL26CV12;128
      Init_GAL_Struct(#GAL26CV12)
    Case #SRL26V12;156
      Init_GAL_Struct(#GAL26V12C)
    Case #SRL22V10;138
      ;Init_GAL_Struct(#GAL22V10)
    Case #SRL6001;119
      Init_GAL_Struct(#GAL6001)
    Default
      found=#False
  EndSelect
  If found=#False
      AppendLogEntry("No GAL found!",#MSGERROR)
  EndIf
  
  ProcedureReturn found
  
EndProcedure

Procedure ReadANDArray()
  
  ClearGadgetItems(Fuse_Editor)
  For row=0 To gal\FuseMapRows-1
    Read_Row(#FUSEMAP,row)
    For row_ptr=0 To gal\FuseMapRowWidth-1
      fuse_ptr=row+row_ptr*gal\FuseMapRows
      fusemap(fuse_ptr)=SerBuffer(row_ptr)
    Next row_ptr
  Next row  
  
EndProcedure

Procedure ReadACW()
  
  Read_Row(#ACW)
  For row_ptr=0 To gal\ACW_RowWidth-1
    fusemap(gal\ACW[row_ptr])=SerBuffer(row_ptr)
  Next row_ptr
  
  
  
EndProcedure

Procedure RedrawFuseMap(fuses_total)
  
  ClearGadgetItems(fuse_Editor)
  ;Start=ElapsedMilliseconds()
  
  editor_fuses=fuses_total
  fuses_per_line=gal\FuseMapRows
  For row=0 To Round(fuses_total/fuses_per_line,#PB_Round_Up)-1
    row_txt$=""
    row_start=row*fuses_per_line
    For fuse_ptr=row_start To row_start+fuses_per_line-1
      If fuse_ptr>=fuses_total:Break:EndIf
      row_txt$=LSet(row_txt$,Len(row_txt$)+1,Chr(Asc("0") | editor_fusemap(fuse_ptr)))
    Next fuse_ptr
    AddGadgetItem(Fuse_Editor,-1,"L"+RSet(Str(row*fuses_per_line),#FUSE_ADRESS_DIGITS,"0")+Space(1)+row_txt$)
  Next row
  For bytes=0 To gal\UES_Bytes-1
    uesval=0
    For bit=0 To 7
      uesval=uesval+(editor_fusemap(gal\UES_FirstFuseNo+bytes*8+bit)<<(7-bit))
    Next bit
    If uesval=0:uesval=32:EndIf ;avoid string termination
    uestxt$=uestxt$+Chr(uesval)
  Next bytes
  StatusBarText(0,1,"UES: "+uestxt$)
  StatusBarText(0,0,gal\Ident)
  
EndProcedure

Procedure SetUES()
  
  ClearGadgetItems(Log_Editor)
  If CountGadgetItems(Fuse_Editor)>0
    ues$=InputRequester("User Electronic Signature (UES)", "Enter new UES [max. "+Str(gal\UES_Bytes)+" alphanumeric digits]","HALLO1234")
    ues$=LSet(ues$,gal\UES_Bytes," ")
    For bytes=0 To gal\UES_Bytes-1
      For bit=0 To 7
        editor_fusemap(gal\UES_FirstFuseNo+bytes*8+bit)=(Asc(Mid(ues$,bytes+1))>>(7-bit)) & 1
      Next bit
    Next bytes
    RedrawFuseMap(gal\FusesTotal)
    AppendLogEntry("->UES changed in data array")
    AppendLogEntry("Click on Save or Programm in order to make the change take effect")
  EndIf
  
  
EndProcedure


Procedure.s PES_to_text(output_type)
  
  Static pes_hex$, pes_ascii$
  
  Select output_type
    Case 0 ;init
      nPES_bytes=(gal\FuseMapRowWidth-gal\PES_Offset)/8
      Dim pes(nPES_bytes)
      pes_hex$="":pes_ascii$=""
      For bytes=0 To nPES_bytes-1
        pesval=0
        For bit=0 To 7
          pesval=pesval+(SerBuffer((bytes)*8+gal\PES_Offset+bit)<<bit)
        Next bit
        pes(bytes)=pesval
        pes_hex$=pes_hex$+RSet(Hex(pes(bytes),#PB_Byte),2,"0")+" "
        pes_ascii$=pes_ascii$+Chr(pes(bytes))
      Next bytes
      
      pes_ascii$=ReverseString(RemoveString(pes_ascii$,Chr(255)))
    Case 1 ;for ATMEL only, call only after PES_to_text(0)
      Select Mid(pes_ascii$,1,Len(pes_ascii$)-1)
        Case "1F16V8B", "1F16V8C", "1F16V8Z", "1F20V8B", "1F22V10C", "1F22V10Z", "1F22V10B"
          gal\Ident="ATF"+Mid(pes_ascii$,3,Len(pes_ascii$)-3)
          ProcedureReturn gal\Ident
        Default
          ProcedureReturn ""
      EndSelect
    Default
      ProcedureReturn pes_hex$
  EndSelect
  
EndProcedure

Procedure GetPullUpIdent()
  #MESSAGE="Device Input & I/O Pull-ups: "

    Select PullUpIdent
    Case 0
      AppendLogEntry(#MESSAGE+"NO")
    Case 1
      AppendLogEntry(#MESSAGE+"YES")
    Case 2
      AppendLogEntry(#MESSAGE+"PIN KEEPER")
  EndSelect
EndProcedure


Procedure Read_PES()
  
  
  
  ClearGadgetItems(Log_Editor)
  
  If GAL_scan() =#False:ProcedureReturn #False:EndIf
  
  Message(0)= 1 ;POWER-UP
  Message(1)= 7 ;message length
  Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
  Message(3)=gal\VPP_READ
  Message(4)= gal\ID
  Message(5)= gal\Pins
  Message(6)=0 ;no VPP ramp-up
  SendMessage(Message(1))

  
  Read_Row(#PES)
  
  PES_to_text(0)
  
  detected_gal=gal\ID
  detected_SRL=gal\FuseMapRowWidth+gal\AdrWidth;SRL=shift register length
  error=#True
  ;here's the final init of the GAL structure
  Select gal\ID
    Case #ATF16V8B,#ATF16V8C,#ATF20V8B,#ATF22V10B
      If PES_to_text(1)="" And detected_gal=#ATF22V10B ;if not ATF22V10B -> detect ATF22V10C
        Init_GAL_Struct(#ATF22V10C)
        Read_Row(#PES)
        PES_to_text(0)
        If PES_to_text(1)<>"":error=#False:EndIf
      Else
        error=#False
      EndIf  
      
    Default;  none ATMEL
      If Init_GAL_Struct(pes(2))=#False ;GAL ID unknown?
        Init_GAL_Struct(detected_gal)
      Else ;handle corrupt PES(B2) on GAL20V8/16V8 (either have 64bit SRL)
        If detected_gal=#GAL20V8 And gal\ID<>#GAL20V8 And gal\ID<>#GAL20V8AZ
          Init_GAL_Struct(#GAL20V8AZ)
        ElseIf  detected_gal=#GAL16V8 And gal\ID<>#GAL16V8 And gal\ID<>#GAL16V8AZ
          Init_GAL_Struct(#GAL16V8AZ)
        ElseIf detected_SRL<>gal\FuseMapRowWidth+gal\AdrWidth
          Init_GAL_Struct(detected_gal)
        Else
          error=#False
        EndIf
      EndIf
      
      
      
      If error=#True Or detected_SRL<>gal\FuseMapRowWidth+gal\AdrWidth ;final check for corrupt PES
        AppendLogEntry("PES not valid",#MSGERROR)
      EndIf
  EndSelect
  
  SetProgrammingAlgo()
  AppendLogEntry("Device: "+gal\Ident+" ["+gal\Vendor+"]")
  GetPullUpIdent()
  
  AppendLogEntry("Vpp Supply: "+Chr(9)+StrF(CalcVpp(gal\VPP),1)+"V (prog.)"+Chr(9)+Chr(9)+StrF(CalcVpp(gal\VPP_READ),1)+"V (read)")
  AppendLogEntry("Pulse Timing: "+Chr(9)+Str(gal\ProgTime)+"ms (prog.)"+Chr(9)+Chr(9)+Str(gal\EraseTime)+"ms (erase)")
  AppendLogEntry("PES: "+PES_to_text(2))
  ProcedureReturn #True
  
EndProcedure



Procedure WriteUES()
  
  
  If Read_PES()
    
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    
    Message(0)= 1 ;POWER-UP
    Message(1)= 6 ;message length
    Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
    Message(3)=gal\VPP                  
    Message(4)= gal\ID
    Message(5)= gal\Pins
    SendMessage(Message(1))
    
    FillMemory(@message(10),gal\FuseMapRowWidth)
    CopyMemory(@editor_fusemap(gal\UES_FirstFuseNo),@message(10+gal\UES_Offset),gal\UES_Bytes*8)
    
    Write_Row(#UES)
  EndIf
  
  Message(0)= 2 ;SHUT-DOWN
  Message(1)= 2 ;message length
  
  SendMessage(Message(1))
  
EndProcedure

Procedure SetFeature(feature)
  
  If Read_PES()
    Message(0)= 1 ;POWER-UP
    Message(1)= 6 ;message length
    Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
    Message(3)=gal\VPP                  
    Message(4)= gal\ID
    Message(5)= gal\Pins
    SendMessage(Message(1))
    
    Write_Row(feature)
    
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    ProcedureReturn #True
  EndIf
  ProcedureReturn #False
  
EndProcedure

Procedure ATF_Conditioning()
  
  
  If Read_PES()
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    
    Message(0)= 1 ;POWER-UP
    Message(1)= 8 ;message length
    Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
    Message(3)=gal\VPP
    Message(4)= gal\ID
    Message(5)= gal\Pins
    Message(6)=1
    Message(7)=gal\VPP_READ
    SendMessage(Message(1))
    
    gal\ProgTime=1
    For n=1 To 2  
      AppendLogEntry("->erase")
      Write_Row(#BULKERASE)
      
      AppendLogEntry("->conditioning")
      ;write (all zeros) AND array 
      FillMemory(@message(10),gal\FuseMapRowWidth)
      Write_Row(#FUSEMAP,0,gal\FuseMapRows)
      
      ;write (all zeros) Architecture Control Word (ACW)
      FillMemory(@message(10),gal\ACW_RowWidth)
      Write_Row(#ACW)
      
      ;write (all zeros) User Electronic Signature (UES)
      FillMemory(@message(10),gal\FuseMapRowWidth) 
      Write_Row(#UES)
      
    Next n
    
  EndIf
  
  Message(0)= 2 ;SHUT-DOWN
  Message(1)= 2 ;message length
  SendMessage(Message(1))
  
  
EndProcedure

Procedure EraseGAL(eraseall=#False)
  
  If Read_PES()
    Message(0)= 1 ;POWER-UP
    Message(1)= 8 ;message length
    Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
    Message(3)=gal\VPP
    Message(4)=gal\ID
    Message(5)=gal\Pins
    Message(6)=1;VPP ramp-up
    Message(7)=gal\VPP_READ
    SendMessage(Message(1))
    
    If eraseall=#False
      Write_Row(#BULKERASE)
    Else
      Select gal\ID
        Case #ATF16V8B,#ATF16V8C,#ATF20V8B,#ATF22V10B,#ATF22V10C
          AppendLogEntry("ATMEL devices do not support this feature")
        Default
          Write_Row(#ERASEALL)
      EndSelect
    EndIf
    
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    ProcedureReturn #True
  EndIf
  ProcedureReturn #False
  
EndProcedure


Procedure ReadGAL(verify=#False, pes_check=#True)
  
  If pes_check=#True
    pes_check_result=Read_PES()
  EndIf
  
  If pes_check=#False Or pes_check_result=#True
    If verify=#False
      ClearGadgetItems(Fuse_Editor)
      AppendLogEntry("->read")
    Else
      AppendLogEntry("->verify")
    EndIf
    FillMemory(fusemap(),ArraySize(fusemap()))
    Select gal\ID

      Case #GAL6001,#GAL6001B,#GAL6002B
        For row=0 To gal\FuseMapRows-1
          Read_Row(#FUSEMAP,(row<<1)+1);95bits
          For bit=0 To 10
            fusemap(7296+78*bit+row)=SerBuffer(20+bit)
          Next bit
           For bit=0 To 63
            fusemap(114*bit+row)=SerBuffer(20+11+bit)
          Next bit         
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row
        
        For row=0 To 63
          FillMemory(@message(10),gal\FuseMapRowWidth+gal\AdrWidth);clear 119bits
          FillMemory(@message(10+31),64,1) ;all row selectors=1
          Message(10+31+row)=0 ;row selection
          Read_Row(#FUSE_OR) ;send 119bit address; receive 119bits
          For bit=0 To 19
            fusemap(78+114*row+bit)=SerBuffer(bit)
          Next bit
           For bit=0 To 15
            fusemap(98+114*row+bit)=SerBuffer(20+83+bit)
          Next bit         
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row       
      Default
        
        For row=0 To gal\FuseMapRows-1
          Read_Row(#FUSEMAP,row)
          For row_ptr=0 To gal\FuseMapRowWidth-1
            fusemap(row+row_ptr*gal\FuseMapRows)=SerBuffer(row_ptr)
          Next row_ptr
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row
    EndSelect
    
    
    Read_Row(#ACW)
    For row_ptr=0 To gal\ACW_RowWidth-1
      fusemap(gal\ACW[row_ptr])=SerBuffer(row_ptr)
    Next row_ptr
    
    Read_Row(#UES)
    CopyMemory(@SerBuffer(gal\UES_Offset),@fusemap(gal\UES_FirstFuseNo),gal\UES_Bytes*8)
    
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    
    If verify=#False
      CopyMemory(fusemap(),editor_fusemap(),gal\FusesTotal)
      RedrawFuseMap(gal\FusesTotal)
      fuses=gal\FusesTotal
    Else
      If CompareMemory(fusemap(),editor_fusemap(),gal\FusesTotal)=#False
        For n=0 To gal\FusesTotal-1
          If editor_fusemap(n)<>fusemap(n):Break:EndIf
        Next n
        AppendLogEntry("VERIFY failed @ fuse #"+Str(n),#MSGERROR)
        Beep_(440,300)
      Else
        AppendLogEntry("*** SUCCESS ***")
      EndIf
    EndIf
    StatusBarProgress(0,2,0)
  EndIf
  
  
  
EndProcedure

Procedure WriteGAL()
  
  
  If Read_PES()
    Message(0)= 2 ;SHUT-DOWN
    Message(1)= 2 ;message length
    SendMessage(Message(1))
    
    Message(0)= 1 ;POWER-UP
    Message(1)= 8 ;message length
    Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
    Message(3)=gal\VPP
    Message(4)= gal\ID
    Message(5)= gal\Pins
    Message(6)=1 ;VPP ramp-up
    Message(7)=gal\VPP_READ
    SendMessage(Message(1))
    
    
    AppendLogEntry("->erase")
    Write_Row(#BULKERASE)
    
    ;write AND array
    
    AppendLogEntry("->programm")
    Select gal\ID
      Case #GAL6001,#GAL6001B,#GAL6002B
        For row=0 To gal\FuseMapRows-1;write AND array (78 x 75)
          FillMemory(@message(10),gal\FuseMapRowWidth,0) ;clear 95bits
          For bit=0 To 10
            message(10+20+bit)=editor_fusemap(7296+78*bit+row)
          Next bit
          For bit=0 To 63
            message(10+20+11+bit)=editor_fusemap(114*bit+row)
          Next bit
          Write_Row(#FUSEMAP,(row<<1)+1);95bits
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row
        ;write OR array (64 x 36)
        For row=0 To 63
          FillMemory(@message(10),gal\FuseMapRowWidth+gal\AdrWidth);clear 119bits
          FillMemory(@message(10+31),64,1)                         ;all row selectors=1
          Message(10+31+row)=0                                     ;row selection
          For bit=0 To 19
            message(10+bit)=editor_fusemap(78+114*row+bit)
          Next bit
          For bit=0 To 15
            message(10+20+83+bit)=editor_fusemap(98+114*row+bit)
          Next bit
          Write_Row(#FUSE_OR) ;119bits
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row       
      Default
        For row=0 To gal\FuseMapRows-1
          For row_ptr=0 To gal\FuseMapRowWidth-1
            message(10+row_ptr)=editor_fusemap(row+row_ptr*gal\FuseMapRows)
          Next row_ptr
          Write_Row(#FUSEMAP,row)
          StatusBarProgress(0,2,((row+1)*100)/gal\FuseMapRows)
        Next row 
    EndSelect
    
    
    ;write Architecture Control Word (ACW)
    For row_ptr=0 To gal\ACW_RowWidth-1
      message(10+row_ptr)=editor_fusemap(gal\ACW[row_ptr]) ;assemble ACW via architecture look-up table
    Next row_ptr
    Write_Row(#ACW)
    
    ;write User Electronic Signature (UES)
    FillMemory(@message(10),gal\FuseMapRowWidth) 
    CopyMemory(@editor_fusemap(gal\UES_FirstFuseNo),@message(10+gal\UES_Offset),gal\UES_Bytes*8)
    Write_Row(#UES)
    
    Select gal\ID
      Case #ATF16V8C, #ATF22V10C
        If editor_fusemap(gal\FusesTotal)=0
          Write_Row(#ATMEL_PD_DIS)
          AppendLogEntry("->disable ATMEL power-down")
        EndIf
    EndSelect
    
    ReadGAL(#True,#False)
    
    
  EndIf
  
  
EndProcedure

Procedure CopyPES()
  
  MessageRequester("Copy PES","Insert source GAL")
  
  If Read_PES()
    Select gal\ID  
      Case #ATF16V8B,#ATF16V8C,#ATF20V8B,#ATF22V10B,#ATF22V10C
        AppendLogEntry("ATMEL devices do not support this feature")
      Default
        Dim pes_buffer(gal\FuseMapRowWidth)
        
        CopyMemory(SerBuffer(),pes_buffer(),gal\FuseMapRowWidth)
        
        Message(0)= 2 ;SHUT-DOWN
        Message(1)= 2 ;message length
        
        SendMessage(Message(1))
        
        MessageRequester("Copy PES","Insert destination GAL"+gal\Ident)
        
        EraseGAL(#True)
        
        Message(0)= 1 ;POWER-UP
        Message(1)= 8 ;message length
        Message(2)=Round(256/#VREF*#VCC,#PB_Round_Up) ;VCC
        Message(3)=gal\VPP                  
        Message(4)=gal\ID
        Message(5)=gal\Pins
        Message(6)=1;VPP ramp-up
        Message(7)=gal\VPP_READ
        SendMessage(Message(1))
        
        CopyMemory(pes_buffer(),@message(10),gal\FuseMapRowWidth)
        
       Write_Row(#PES)
        
    EndSelect

  EndIf
  Message(0)= 2 ;SHUT-DOWN
  Message(1)= 2 ;message length
  SendMessage(Message(1))
  
  
  
EndProcedure


Procedure Read_JEDEC_file(fname$)
  
  
  If fname$<>""
    ClearGadgetItems(Fuse_Editor)
    ClearGadgetItems(Log_Editor)
    StatusBarText(0,0,"")
    StatusBarText(0,1,"")
    AppendLogEntry("Parsing file: "+GetFilePart(fname$))
    AppendLogEntry("Path: "+GetPathPart(fname$))
    fuses_total=ParseJedec(fname$)
    If fuses=0 :ProcedureReturn:EndIf
    
    ;valid fuse count
    ;a) total fuses (AND array + UES)
    ;b) total fuses +1 (Power Down feature on ATMEL)
    ;c) UES_start (AND array + ACW only, without UES)
    Select fuses_total
      Case #FUSES16V8, #FUSES16V8+1
        Init_GAL_Struct(#GAL16V8)
      Case #FUSES20V8, #FUSES20V8+1
        Init_GAL_Struct(#GAL20V8)
      Case #FUSES18V10, #UES_START18V10
        Init_GAL_Struct(#GAL18V10)
      Case #FUSES20RA10, #UES_START20RA10
        Init_GAL_Struct(#GAL20RA10)
      Case #FUSES20XV10, #UES_START20XV10
        Init_GAL_Struct(#GAL20XV10)
      Case #FUSES22V10, #FUSES22V10+1, #UES_START22V10
        Init_GAL_Struct(#GAL22V10)
      Case #FUSES26CV12, #UES_START26CV12
        Init_GAL_Struct(#GAL26CV12)
      Case #FUSES26V12, #UES_START26V12
        Init_GAL_Struct(#GAL26V12C)
      Case #FUSES6001, #UES_START6001
        Init_GAL_Struct(#GAL6001)
      Case #FUSES6002, #UES_START6002
        Init_GAL_Struct(#GAL6002B)
      Default
        AppendLogEntry(Str(fuses_total)+" fuses don't match any GAL",#MSGERROR)
        ProcedureReturn
    EndSelect
    
    AppendLogEntry(Str(fuses_total)+" fuses match "+gal\Ident)
    fuses=gal\FusesTotal
    RedrawFuseMap(fuses)
  EndIf
  
  
  
EndProcedure

Procedure Save_JEDEC_file()
  
  file$=GetFileName(#True)
  If file$<>""
    If CreateFile(0, file$)
      WriteStringN(0, Chr(2));STX
      WriteStringN(0, "This is a JEDEC compatible fuse file.")
      WriteStringN(0, "CREATED BY: "+#APP_NAME)
      WriteStringN(0, "CREATED DATE: "+FormatDate("%dd/%mm/%yyyy  ", Date())+FormatDate("%hh:%ii:%ss", Date()))
      WriteStringN(0, "*QF"+Str(editor_fuses)+"* F0*"+" G0* ");fuse default=0 & security off
      For n=0 To CountGadgetItems(Fuse_Editor)-1
        If FindString(StringField(GetGadgetItemText(Fuse_Editor,n),2," "),"1")>0; skip lines where all fuses are zeros
          WriteStringN(0, GetGadgetItemText(Fuse_Editor,n)+"*")
        EndIf
      Next n
      WriteStringN(0, "C"+RSet(Hex(CalcChecksum(fuses)),4,"0")+"*")
      WriteStringN(0, Chr(3));ETX
      CloseFile(0)
    Else
      AppendLogEntry("Can't access file",#MSGERROR)
    EndIf
  EndIf
  
EndProcedure

Procedure ToolBarClick(ToolbarButton)
  
  For n=0 To 4
    ;   DisableToolBarButton(0,n,1)
  Next n
  
  DisableToolBarButton(0,ToolbarButton,0)
  Select ToolbarButton
    Case #TBAR_OPEN,#MENU_OPEN ;read JEDEC file
      FileTemp=GetFilename()
      Read_JEDEC_file(FileTemp)
      
    Case #TBAR_SAVE,#MENU_SAVE;save JEDEC file
      Save_JEDEC_file()
      
    Case #TBAR_COMPILE ;compile & run
      fname$=GetFilename(#False,1)

      If CompileABEL(fname$)=#True
        FileTemp=fname$
        Read_JEDEC_file(GetPathPart(fname$)+GetFilePart(fname$,#PB_FileSystem_NoExtension)+".jed")
        GetPinoutFromDoc()
      EndIf
      
      
    Case #TBAR_READ ;read GAL
      FileTemp=""
      ReadGAL()
      
    Case #TBAR_WRITE ;programm GAL
      WriteGAL()
      
    Case #TBAR_VERIFY ;verify GAL
      ReadGAL(#True)
      
    Case #TBAR_ERASE ;erase GAL
      EraseGAL()
      
    Case #TBAR_INFO
      GetPinoutFromDoc()
      DrawPinout()
      
    Case #TBAR_TEST;test
      

      
    Case #MENU_SET_UES
      SetUES()
    Case #MENU_CLEARALL
      EraseGAL(#True)
    Case #MENU_COPY_PES
      CopyPES()
    Case #MENU_ATMEL_PD_DIS
      SetFeature(#ATMEL_PD_DIS)
    Case #MENU_ATMEL_CONDITIONING
      ATF_Conditioning()
    Case #MENU_SECURITY
      SetFeature(#SECURITY)
    Case #MENU_SUPPLY_TEST
      SupplyTest()
    Case #MENU_SUPPORTED_DEVICES
      MessageRequester("Devices","GAL16V8"+#CRLF$+"GAL18V10"+#CRLF$+"GAL20V8"+#CRLF$+"GAL20XV10"+#CRLF$+"GAL20RA10"+#CRLF$+"GAL22V10"+ 
                       #CRLF$+"ATF16V8"+#CRLF$+"ATF20V8"+#CRLF$+"ATF22V10"+#CRLF$+"GAL26V12"+#CRLF$+"GAL26CV12"+#CRLF$+"GAL6001 (GAL39V18)"+#CRLF$+"GAL6002")
    Case #MENU_ABOUT
      MessageRequester(#APP_NAME,#APP_VERSION+#CRLF$+"Built: "+FormatDate("%dd.%mm.%yyyy",#APP_BUILT)+"; PB"+#PB_Compiler_Version+#CRLF$+#CRLF$+#APP_BY)
      
  EndSelect
  
  If ErrorLevel=0
    AppendLogEntry (">>> done <<<")
  Else
    AppendLogEntry ("-- aborted --")
  EndIf
  
  SetToolBarButtonState(0,ToolbarButton,0)
  For n=0 To 4
    DisableToolBarButton(0,n,0)
  Next n
  
EndProcedure



Procedure ScanComPorts()
  
  If IsSerialPort(0):CloseSerialPort(0):EndIf
  
  For n=0 To #MAXCOMPORTS
    
    ComPort.s="COM"+Str(n)
    
    If OpenSerialPort(0, ComPort, 115200, #PB_SerialPort_NoParity, 8, 1, #PB_SerialPort_NoHandshake, #InBufSize, #OutBufSize)
     
      
      SetSerialPortStatus(0,#PB_SerialPort_TXD,1)
      Delay(1)
      SetSerialPortStatus(0,#PB_SerialPort_TXD,0)
      Delay(1)
      SetSerialPortStatus(0,#PB_SerialPort_TXD,1)
      Delay(1)
      SetSerialPortStatus(0,#PB_SerialPort_TXD,0)
      Delay(40)

      If AvailableSerialPortInput(0)>1
        While AvailableSerialPortInput(0)<>0
          ReadSerialPortData(0, @SerBuf.s{1}, 1)
          If Asc(SerBuf)<>0
            SerResponse.s =SerResponse.s + SerBuf
          EndIf
        Wend
        If FindString(SerResponse.s , #PWR_ON_MSG,1)>0
          AppendLogEntry(#PWR_ON_MSG + " found @ "+ComPort)
          ProcedureReturn #True
        EndIf 
      EndIf
      CloseSerialPort(0)
    EndIf
  Next n
  ProcedureReturn #False
  
EndProcedure

Procedure Scan()
  
  Device=0
  ErrorLevel=0
  ClearGadgetItems(Fuse_Editor)
  ClearGadgetItems(Log_Editor)
  WaitWindowEvent(10)
  
  If ScanComPorts()=#False
    MessageRequester(#APP_NAME, "Hardware not present!")
    End
  EndIf
  
  
EndProcedure



Procedure WindowEventHandler()
  
  Select EventGadget()
    Case 0
      splitter_h= WindowHeight(Window_0, #PB_Window_InnerCoordinate)-ToolBarHeight(0)-StatusBarHeight(0)-40
      ResizeGadget(Splitter_0, #PB_Ignore, #PB_Ignore,WindowWidth(Window_0, #PB_Window_InnerCoordinate)-10,splitter_h)
  EndSelect 
  
EndProcedure

;==================================================================================================

InitWindow_0()
BindEvent(#PB_Event_SizeWindow,@WindowEventHandler(),Window_0)

Scan()

AppendLogEntry("Welcome "+#APP_NAME+" user")

;Init_GAL_Struct(#GAL6002B)

Repeat
  ErrorLevel=0
  Event = WaitWindowEvent()
  Select Event
    Case #PB_Event_Menu
      ToolBarClick(EventMenu())
    Case #PB_Event_Gadget
      Select EventGadget()
      EndSelect
  EndSelect
  If ErrorLevel>=#ERR_ATMEGA
    AppendLogEntry("Resetting...")
    Delay(600)
    Scan()
  EndIf
Until Event = #PB_Event_CloseWindow


; IDE Options = PureBasic 5.70 LTS (Windows - x64)
; CursorPosition = 1
; Folding = -------
; EnableXP
; UseIcon = ic-icon1.ico
; Executable = GALmate.exe