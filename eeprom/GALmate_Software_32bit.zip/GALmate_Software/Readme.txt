The autoexec.txt file is only for use with vDosPlus.
If you use vDosPlus:
Replace the autoexec.txt file in the vDosPlus folder with the one provided.