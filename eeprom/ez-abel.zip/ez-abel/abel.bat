@echo off
rem ----------------------------------------------------------------
rem Ce batch ABEL.BAT convertit un fichier ABEL en fichier JEDEC
rem Il est compatible avec le generateur de code d'ISIS Proteus 7.8
rem
rem Fichier batch cree par Jean-Christophe MICHEL
rem 20 fevrier 2012
rem www.gecif.net
rem ----------------------------------------------------------------

del *.tt1
del *.tt2

rem %1 est le nom du fichier source ABEL avec l'extension .ABL
rem (en appelant le generateur de code Proteus passe en parametre l'extension)

rem convertit le fichier ABL en fichier TT1 :
ahdl2pla %1
ren *.tt1 gecif.tt1

rem convertit le fichier TT1 en fichier TT2 :
plaopt gecif.tt1

rem convertit le fichier TT2 en fichier JED :
fuseasm gecif.tt2

rem Efface les fichiers temporaires gecif.tt1 et gecif.tt2 :
del *.tt1
del *.tt2


