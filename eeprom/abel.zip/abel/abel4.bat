if exist p:\abel\abel4\abel4.exe goto v_dos
set path=p:\prog\abel\abel4;%path%
set abel4dev=P:\prog\abel\abel4\lib4
set abel4db=P:\prog\abel\abel4\lib4\devices
set db_dict=p:\prog\abel\abel4\lib4\dbase
goto end
:v_dos
set path=p:\abel\abel4;%path%
set abel4dev=P:\abel\abel4\lib4
set abel4db=P:\abel\abel4\lib4\devices
set db_dict=p:\abel\abel4\lib4\dbase
:end
abel4.exe
